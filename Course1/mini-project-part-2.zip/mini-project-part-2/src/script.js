var image = null;
var gsimage = null;
var redimage = null;

function upload(){
  var finput = document.getElementById("finput");
  var canvas = document.getElementById("canvas");
  image = new SimpleImage(finput);
  image.drawTo(canvas);
}

function clearCanvas(){
  var canvas = document.getElementById("canvas");
  var ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);
}

function doGreyscale(){
  if(image == null || !image.complete()){
    alert("Image is not uploaded yet...!");
    return;
  }
  
  gsimage = new SimpleImage(image.width, image.height);
  var canvas = document.getElementById("canvas");
  for(var p of image.values()){
    var avg = (p.getRed() + p.getGreen() + p.getBlue()) / 3;
    var x = p.getX();
    var y = p.getY();
    var pixel = gsimage.getPixel(x, y);
    pixel.setRed(avg);
    pixel.setGreen(avg);
    pixel.setBlue(avg);
    
  }
  clearCanvas();
  gsimage.drawTo(canvas);
  
}

function doRed(){
  if(image == null || !image.complete()){
    alert("Image is not uploaded yet...!");
    return;
  }
  
  redimage = new SimpleImage(image.width, image.height);
  var canvas = document.getElementById("canvas");
  for(var p of image.values()){
    var x = p.getX();
    var y = p.getY();
    var pixel = redimage.getPixel(x, y);
    pixel.setRed(p.getRed());
    pixel.setGreen(0);
    pixel.setBlue(0);
    
  }
  clearCanvas();
  redimage.drawTo(canvas);
}

function doReset(){
  if(image == null || !image.complete()){
    alert("Image is not uploaded yet...!");
    return;
  }
  var canvas = document.getElementById("canvas");
  clearCanvas();
  image.drawTo(canvas);
  
}

function drawplus(x1, y1, x2, y2, ctx, hmar, vmar){
  var x = parseInt((x1 + x2) / 2);
  var y = parseInt((y1 + y2) / 2);
  var hm = parseInt(hmar / 4);
  var vm = parseInt(vmar / 4);
  ctx.clearRect(x - vm, y1, 2 * vm, y2);
  ctx.clearRect(x1, y - hm, x2, 2 * hm);
  
  
}
function doWindowpane(){
  if(image == null || !image.complete()){
    alert("Image is not uploaded yet...!");
    return;
  }
  var canvas = document.getElementById("canvas");
  var width = canvas.width;
  var height = canvas.height;
  var horizmargin = 20;
  var verticalmargin = 20;
  var ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, verticalmargin, height);
  ctx.clearRect(0, 0, width, horizmargin);
  ctx.clearRect(0, height - horizmargin, width, height)
  ctx.clearRect(width - verticalmargin, 0, width, height);
  drawplus(0, 0, width, height, ctx, horizmargin, verticalmargin);
  
}
