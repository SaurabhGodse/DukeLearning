var image;
function upload(){
  var finput = document.getElementById("finput");
  var canvas = document.getElementById("canvas1");
  image = new SimpleImage(finput);
  image.drawTo(canvas);
}
function makeGrey(){
  for(var p of image.values()){
    var avg = (p.getRed() + p.getGreen() + p.getBlue()) / 3;
    p.setRed(avg);
    p.setGreen(avg);
    p.setBlue(avg);
  }
  var canvas = document.getElementById("canvas2");
  image.drawTo(canvas);
  
}