var fgimage = null;
var bgimage = null;
var width = 300;
var height = 150;
function fgupload(){
  var fginput = document.getElementById("fginput");
  var canvas = document.getElementById("canvas1");
  fgimage = new SimpleImage(fginput);
  fgimage.drawTo(canvas);
}

function bgupload(){
  var bginput = document.getElementById("bginput");
  var canvas = document.getElementById("canvas2");
  bgimage = new SimpleImage(bginput);
  bgimage.drawTo(canvas);
  
}

function clearCanvas(){
  var canvas1 = document.getElementById("canvas1");
  var ctx1 = canvas1.getContext("2d");
  ctx1.clearRect(0, 0, canvas1.width, canvas1.height);
  var canvas2 = document.getElementById("canvas2");
  var ctx2 = canvas2.getContext("2d");
  ctx2.clearRect(0, 0, canvas2.width, canvas2.height);
}

function doGreenScreen(){
  if(fgimage == null || ! fgimage.complete()){
    alert("Foreground image is not uploaded...!");
  }
  if(bgimage == null || ! bgimage.complete()){
    alert("Background image is not uploaded...!");
  }
  var image = new SimpleImage(fgimage.width, fgimage.height);
  bgimage.setSize(fgimage.width, fgimage.height);
  for(var p of fgimage.values()){
    var x = p.getX();
    var y = p.getY();
    if(p.getGreen() > p.getRed() + p.getBlue()){
      image.setPixel(x, y, bgimage.getPixel(x, y));
    }
    else{
      image.setPixel(x, y, p);
    }
  }
  clearCanvas();
  var canvas1 = document.getElementById("canvas1");
  image.drawTo(canvas1);
}