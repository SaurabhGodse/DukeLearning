function upload(){
  var finput = document.getElementById("finput");
  var canvas = document.getElementById("canvas");
  var image = new SimpleImage(finput);
  image.drawTo(canvas);
}